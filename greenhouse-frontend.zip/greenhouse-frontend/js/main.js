// main.js - simple frontend logic
const form = document.getElementById('predictForm');
if(!form) { console.warn('predictForm not found on page.'); }
const resultCard = document.getElementById('resultCard');
const predictionValue = document.getElementById('predictionValue');
const predictBtn = document.getElementById('predictBtn');
const spinner = document.getElementById('spinner');
const demoBtn = document.getElementById('demoBtn');
const csvInput = document.getElementById('csvUpload');

// Default endpoint: change to your actual prediction endpoint when ready
const API_URL = '/predict'; // e.g. 'http://127.0.0.1:5000/predict'

function showSpinner(on=true) {
  if (!spinner) return;
  spinner.classList.toggle('hidden', !on);
}

function showResult(value, modelName='Demo Model') {
  if (!predictionValue || !resultCard) return;
  predictionValue.textContent = value;
  const modelSpan = document.getElementById('modelName');
  if (modelSpan) modelSpan.textContent = modelName;
  resultCard.classList.remove('hidden');
  // scroll into view on small screens
  resultCard.scrollIntoView({behavior:'smooth', block:'center'});
}

// simple CSV parsing (first numeric row used)
function parseCSV(file, cb) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const text = e.target.result;
      const lines = text.trim().split('\n').filter(Boolean);
      if (lines.length < 2) return cb({});
      const header = lines[0].split(/,|;|\t/).map(h=>h.trim());
      const values = lines[1].split(/,|;|\t/).map(v=>v.trim());
      const obj = {};
      header.forEach((h,i)=> obj[h]=values[i]);
      cb(obj);
    } catch(err) {
      cb({});
    }
  };
  reader.readAsText(file);
}

if (form) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    showSpinner(true);
    const fd = new FormData(form);
    const payload = {
      temperature: parseFloat(fd.get('temperature')),
      humidity: parseFloat(fd.get('humidity')),
      fuel: parseFloat(fd.get('fuel')),
      feature_x: parseFloat(fd.get('feature_x') || 0)
    };

    // If a CSV is uploaded, parse and send first row
    if (csvInput && csvInput.files && csvInput.files.length) {
      parseCSV(csvInput.files[0], async (obj) => {
        // merge parsed fields if they exist (strings -> numbers attempt)
        Object.keys(obj).forEach(k => {
          const n = Number(obj[k]);
          if (!isNaN(n)) obj[k] = n;
        });
        Object.assign(payload, obj);
        await callPredict(payload);
      });
    } else {
      await callPredict(payload);
    }
  });
}

// Demo button behavior: prefill and run
if (demoBtn) {
  demoBtn.addEventListener('click', async () => {
    const demo = { temperature: 25.4, humidity: 60, fuel: 12.5, feature_x: 0.5 };
    // prefill UI (if inputs exist)
    if (form) {
      if (form.temperature) form.temperature.value = demo.temperature;
      if (form.humidity) form.humidity.value = demo.humidity;
      if (form.fuel) form.fuel.value = demo.fuel;
      if (form.feature_x) form.feature_x.value = demo.feature_x;
    }
    await callPredict(demo);
  });
}

async function callPredict(payload) {
  try {
    showSpinner(true);

    // Demo behaviour: if API_URL is default '/predict' and no server exists,
    // we simulate a response so UI can be tested offline.
    if (API_URL === '/predict') {
      await new Promise(r => setTimeout(r, 600));
      const mockVal = ( (payload.fuel||0) * 0.8 + (payload.temperature||0) * 0.1 + (payload.humidity||0) * 0.05 );
      const mock = { prediction: mockVal.toFixed(3), model: 'Demo-LR' };
      showResult(mock.prediction + ' kg CO₂e', mock.model);
      drawTrendChart([mock.prediction, (parseFloat(mock.prediction) * 1.02).toFixed(3), (parseFloat(mock.prediction) * 0.98).toFixed(3)]);
      return;
    }

    // Otherwise attempt real request to API_URL
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      // throw to be handled by catch and fallback
      throw new Error('Request failed: ' + res.status);
    }

    let data = null;
    try { data = await res.json(); } catch(e) { throw new Error('Invalid JSON response'); }

    if (!data || typeof data.prediction === 'undefined') {
      throw new Error('Response missing "prediction" field');
    }

    showResult(data.prediction + (String(data.prediction).toLowerCase().includes('kg') ? '' : ' kg CO₂e'), data.model || 'Model');
    if (data.series) drawTrendChart(data.series);
  } catch (err) {
    console.error('Prediction error:', err);
    // Fallback: compute and show demo prediction so UI remains usable
    try {
      const fallback = ( (payload.fuel||0) * 0.8 + (payload.temperature||0) * 0.1 + (payload.humidity||0) * 0.05 ).toFixed(3);
      showResult(fallback + ' kg CO₂e', 'Fallback-Demo');
      drawTrendChart([fallback, (parseFloat(fallback)*1.02).toFixed(3), (parseFloat(fallback)*0.98).toFixed(3)]);
    } catch(e) { /* ignore */ }
    // If you want to see error details, uncomment the next line:
    // alert('Prediction error: ' + err.message + '\nShowing fallback demo result.');
  } finally {
    showSpinner(false);
  }
}

// minimal chart using canvas
function drawTrendChart(series=[]) {
  const container = document.getElementById('chart');
  if (!container) return;
  container.innerHTML = '';
  if (!series || !series.length) return;
  const canvas = document.createElement('canvas');
  canvas.width = Math.min(600, Math.max(300, container.clientWidth || 400));
  canvas.height = 120;
  container.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  const nums = series.map(Number);
  const max = Math.max(...nums);
  const min = Math.min(...nums);
  const pad = 10;
  const w = canvas.width - pad*2;
  const h = canvas.height - pad*2;
  ctx.beginPath();
  nums.forEach((v,i)=>{
    const x = pad + (i/(nums.length-1 || 1)) * w;
    const y = pad + (1 - (v-min)/(max-min || 1)) * h;
    if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    ctx.fillStyle = '#10b981';
    ctx.beginPath();
    ctx.arc(x,y,3,0,Math.PI*2);
    ctx.fill();
  });
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 2;
  ctx.stroke();
}

// mobile menu toggle
const mobileBtn = document.getElementById('mobileMenuBtn');
if (mobileBtn) {
  mobileBtn.addEventListener('click', ()=>{
    const mm = document.getElementById('mobileMenu');
    if (mm) mm.classList.toggle('hidden');
  });
}
